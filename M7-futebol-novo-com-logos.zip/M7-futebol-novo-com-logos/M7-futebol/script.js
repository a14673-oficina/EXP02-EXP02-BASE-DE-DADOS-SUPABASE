const SUPABASE_URL = "https://xzgqtemjokgwunacfkuc.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh6Z3F0ZW1qb2tnd3VuYWNma3VjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgxNDY1MTEsImV4cCI6MjA5MzcyMjUxMX0.a0K79ZlM7P3Zxzwvr-H0BpDv5nBUysxtbtwMqV6DZME";

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// Mapeamento de clubes para logos
const logoMap = {
  "FC Porto": "logos/fc_porto.png",
  "Real Madrid": "logos/real_madrid.png",
  "Manchester U": "logos/manchester_united.png",
  "SL Benfica": "logos/sl_benfica.png",
  "Hertha-Berliner SC": "logos/hertha_bsc.png",
  "Servette FC": "logos/servette_fc.png",
  "April 25 Sports Club (4.25 SC)": "logos/april_25.png"
};

async function carregarClubes() {
  const { data, error } = await supabaseClient
    .from("clube")
    .select("*")
    .order("nomeclube");

  const div = document.getElementById("clubes");

  if (error) {
    div.innerHTML = "Erro ao carregar clubes.";
    console.log(error);
    return;
  }

  div.innerHTML = "";

  data.forEach(clube => {
    div.innerHTML += `
      <div class="card">
        <strong>${clube.nomeclube}</strong><br>
        País: ${clube.pais}<br>
        Idade: ${clube.idade}<br>
        Estádio: ${clube.estadio}
      </div>
    `;
  });
}

async function carregarJogadores() {
  const { data, error } = await supabaseClient
    .from("jogador")
    .select("*")
    .order("numatleta");

  const div = document.getElementById("jogadores");

  if (error) {
    div.innerHTML = "Erro ao carregar jogadores.";
    console.log(error);
    return;
  }

  mostrarJogadores(data);
}

async function adicionarJogador() {
    const jogador = {
        nomejogador: document.getElementById("nomejogador").value,
        pais: document.getElementById("pais").value,
        idade: Number(document.getElementById("idade").value),
        posicao: document.getElementById("posicao").value,
        nomeclube: document.getElementById("nomeclube").value,
    };

    const { data, error} = await supabaseClient
        .from("jogador")
        .insert([jogador])
        .select();
    
    const mensagem = document.getElementById("mensagem");

    if (error) {
        mensagem.textContent = "Erro ao adicionar jogador.";
        console.log(error);
        return;
    }

    mensagem.textContent = "Jogador adicionar com sucesso.";
    
    // Limpar campos
    document.getElementById("nomejogador").value = "";
    document.getElementById("pais").value = "";
    document.getElementById("idade").value = "";
    document.getElementById("posicao").value = "";
    document.getElementById("nomeclube").value = "";
    
    carregarJogadores();
}

async function apagarJogador(id) {
    const confirmar = confirm("Tem certeza que deseja apagar este jogador?");

    if (!confirmar) return;

    const { error } = await supabaseClient
        .from("jogador")
        .delete()
        .eq("numatleta", id);

    if (error) {
        alert("Erro ao apagar jogador.");
        console.log(error);
        return;
    }

    alert("Jogador apagado com sucesso.");
    carregarJogadores();
}

async function abrirModalEditar(jogador) {
  document.getElementById("editId").value = jogador.numatleta;
  document.getElementById("editNome").value = jogador.nomejogador;
  document.getElementById("editPais").value = jogador.pais;
  document.getElementById("editIdade").value = jogador.idade;
  document.getElementById("editPosicao").value = jogador.posicao;
  document.getElementById("editClube").value = jogador.nomeclube;

  document.getElementById("modalEditar").style.display = "block";
}

async function fecharModal() {
  document.getElementById("modalEditar").style.display = "none";
}

async function guardarEdicao() {
  const id = document.getElementById("editId").value;

  const jogadorAtualizado = {
    nomejogador: document.getElementById("editNome").value,
    pais: document.getElementById("editPais").value,
    idade: Number(document.getElementById("editIdade").value),
    posicao: document.getElementById("editPosicao").value,
    nomeclube: document.getElementById("editClube").value
  };

  const { error } = await supabaseClient
    .from("jogador")
    .update(jogadorAtualizado)
    .eq("numatleta", id);

  if (error) {
    alert("Erro ao atualizar jogador.");
    console.log(error);
    return;
  }

  fecharModal();
  carregarJogadores();
}

async function filtrarPorPais() {
  const pais = document.getElementById("filtroPais").value;

  if (!pais) {
    carregarJogadores();
    return;
  }

  const { data, error } = await supabaseClient
    .from("jogador")
    .select("*")
    .eq("pais", pais);

  if (error) {
    console.log(error);
    return;
  }

  mostrarJogadores(data);
}

async function filtrarPorClube() {
  const clube = document.getElementById("filtroClube").value;

  if (!clube) {
    carregarJogadores();
    return;
  }

  const { data, error } = await supabaseClient
    .from("jogador")
    .select("*")
    .eq("nomeclube", clube);

  if (error) {
    console.log(error);
    return;
  }

  mostrarJogadores(data);
}

async function mostrarJogadores(data) {
  const div = document.getElementById("jogadores");

  div.innerHTML = "";

  if (data.length === 0) {
    div.innerHTML = "<p>Nenhum jogador encontrado.</p>";
    return;
  }

    data.forEach(jogador => {
        const logoUrl = logoMap[jogador.nomeclube] || "logos/default.png";
        div.innerHTML += `
            <div class="card" data-clube="${jogador.nomeclube}">
                <div class="jogador-header">
                    <img src="${logoUrl}" alt="Logo ${jogador.nomeclube}" class="clube-logo">
                    <div class="jogador-info">
                        <strong>${jogador.nomejogador}</strong><br>
                        <span class="clube-nome">${jogador.nomeclube}</span>
                    </div>
                </div>
                <div class="jogador-details">
                    País: ${jogador.pais}<br>
                    Idade: ${jogador.idade}<br>
                    Posição: ${jogador.posicao}
                </div>
                <div class="jogador-actions">
                    <button onclick='abrirModalEditar(${JSON.stringify(jogador)})'>Editar</button>
                    <button onclick="apagarJogador(${jogador.numatleta})">Apagar</button>
                </div>
            </div>
        `;
    });
}

carregarClubes();
carregarJogadores();
